var tl = gsap.timeline()
function time() {
  var a = 0;
  setInterval(function() {
    a = a + Math.floor(Math.random()*10)
    if (a < 100) {
      document.querySelector("#loader h1").innerHTML = a + "%"
    } else {
      a = 100
      document.querySelector("#loader h1").innerHTML = a + "%"
    };
  },150);
};

tl.to("#loader",{
  y:"-100vh",
  delay:4,
  duration:1.5
})

tl.to("#loader h1",{
  delay:4,
  duration:1,
  onStart:time()
})
 tl.from("#nav h3,#nav #center a,#nav button",{
   y:-100,
   duration:0.3,
   delay:0.1,
   opacity:0,
   stagger:0.2,
 })
 tl.from("#main>h1",{
   y:500,
   opacity:0,
   scale:0,
   dutation:0.5,
   delay:0.3,
   stagger:0.5,
 })
 tl.from("#main>h3",{
   y:40,
   opacity:0,
   scale:0,
   duration:0.3,
   delay:0.3,
   stagger:0.5,
 })
 tl.to("#main>h3",{
   y:40,
   duraion:0.3, delay:0.3,
   stagger:0.5,
   repeat:-1,
   yoyo:true,
 })

