var con = document.querySelector(".con");
var crsr = document.querySelector("#cursor");


con.addEventListener("mousemove",function(dets){
  
crsr.style.left = dets.x+'px'
crsr.style.top = dets.y+'px'
  
  
});