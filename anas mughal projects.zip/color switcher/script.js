const button1 = document.querySelector("#yellow");
const button2 = document.querySelector("#green");
const button3 = document.querySelector("#red");
const button4 = document.querySelector("#blue");
const button5 = document.querySelector("#skyblue");
const button6 = document.querySelector("#hotpink");
const button7 = document.querySelector("#lightgreen");
const button8 = document.querySelector("#orange");
const button9 = document.querySelector("#burlywood");
const button10 = document.querySelector("#purple");
var body = document.querySelector("body")


button1.addEventListener("click", function(){
  body.style.backgroundColor = "yellow"
});

button2.addEventListener("click", function() {
  body.style.backgroundColor = "green"
});

button3.addEventListener("click", function() {
  body.style.backgroundColor = "red"
});

button4.addEventListener("click", function() {
  body.style.backgroundColor = "blue"
});

button5.addEventListener("click", function() {
  body.style.backgroundColor = "skyblue"
});

button6.addEventListener("click", function() {
  body.style.backgroundColor = "hotpink"
});

button7.addEventListener("click", function() {
  body.style.backgroundColor = "lightgreen"
});

button8.addEventListener("click", function() {
  body.style.backgroundColor = "orange"
});

button9.addEventListener("click", function() {
  body.style.backgroundColor = "burlywood"
});

button10.addEventListener("click", function() {
  body.style.backgroundColor = "purple"
});

