function one(){
  var elem1 = document.querySelector("#elem1");
  var img1 = document.querySelector("#elem1 img")
  
  elem1.addEventListener("mousemove", function(dets) {
    img1.style.left = dets.x + "px"
    img1.style.top = dets.y + "px"
  });
  
  elem1.addEventListener("mouseenter", function() {
    img1.style.opacity = 1
  });
  
  elem1.addEventListener("mouseleave", function() {
    img1.style.opacity = 0
  });
};
one();

function two() {
  var elem2 = document.querySelector("#elem2");
  var img2 = document.querySelector("#elem2 img")

  elem2.addEventListener("mousemove", function(dets) {
    img2.style.left = dets.x + "px"
    img2.style.top = dets.y + "px"
  });

  elem2.addEventListener("mouseenter", function() {
    img2.style.opacity = 1
  });

  elem2.addEventListener("mouseleave", function() {
    img2.style.opacity = 0
  });
};
two();


function three() {
  var elem3 = document.querySelector("#elem3");
  var img3 = document.querySelector("#elem3 img")

  elem3.addEventListener("mousemove", function(dets) {
    img3.style.left = dets.x + "px"
    img3.style.top = dets.y + "px"
  });

  elem3.addEventListener("mouseenter", function() {
    img3.style.opacity = 1
  });

  elem3.addEventListener("mouseleave", function() {
    img3.style.opacity = 0
  });
};
three();


function four() {
  var elem4 = document.querySelector("#elem4");
  var img4 = document.querySelector("#elem4 img")

  elem4.addEventListener("mousemove", function(dets) {
    img4.style.left = dets.x + "px"
    img4.style.top = dets.y + "px"
  });

  elem4.addEventListener("mouseenter", function() {
    img4.style.opacity = 1
  });

  elem4.addEventListener("mouseleave", function() {
    img4.style.opacity = 0
  });
};
four();
