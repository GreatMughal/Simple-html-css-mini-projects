var istatus = document.querySelector("h5");
var addfr = document.querySelector(".add");
var card = document.querySelector("#card");
var check = 0;
addfr.addEventListener("click",function(){
  if (check == 0) {
    istatus.innerHTML = "Friends"
    istatus.style.color = "green"
    addfr.innerHTML = "Remove Fri";
    
    card.style.boxShadow = "0 0 5px green, 0 0 25px green"
    check = 1;
  } else {
    istatus.innerHTML = "Stranger"
    istatus.style.color = "red"
    addfr.innerHTML = "Add Friend"
    card.style.boxShadow = "0 0 5px red,  0 0 25px red"
    check = 0
  };
});