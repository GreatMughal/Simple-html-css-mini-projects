var icon = document.querySelector("i");
var con = document.querySelector(".container");

con.addEventListener("dblclick",function(){
  icon.style.transform = "translate(-50%, -50%) scale(1)"
  icon.style.opacity = 0.7
  setTimeout(function(){
    icon.style.opacity = 0
  },1000);
  setTimeout(function(){
    icon.style.transform = "translate(-50%, -50%) scale(1)"
  },2000);
});